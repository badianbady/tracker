@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Jachym Air Tracker
set PY=python
python --version >nul 2>&1
if errorlevel 1 set PY=py
%PY% --version >nul 2>&1
if errorlevel 1 (
  echo Python neni nainstalovany. Stahni ho z https://www.python.org/downloads/
  echo Pri instalaci zaskrtni "Add python.exe to PATH".
  pause
  exit /b
)
echo Kontroluji knihovnu SimConnect...
%PY% -m pip install --quiet --disable-pip-version-check SimConnect
%PY% jai_tracker.py
pause
